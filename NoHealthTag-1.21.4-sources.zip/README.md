# No Health Tag (Fabric 1.21.4)

Клиентский мод для Minecraft 1.21.4 на Fabric, скрывающий отображение HP/Scoreboard (belowname) под никами игроков.

## Сборка
1. Установите JDK 21.
2. Выполните:
   - Linux/macOS: `./gradlew build`
   - Windows: `gradlew.bat build`
3. Готовый `.jar` файл будет находиться в папке `build/libs/`.

Либо загрузите репозиторий на GitHub — воркфлоу `.github/workflows/build.yml` автоматически соберет `.jar` через GitHub Actions.
