package com.example.nohealthtag.mixin;

import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.scoreboard.ScoreboardDisplaySlot;
import net.minecraft.scoreboard.ScoreboardObjective;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(PlayerEntityRenderer.class)
public abstract class PlayerEntityRendererMixin {

    /**
     * Перехватываем метод отрисовки текстовых меток под ником.
     * В Minecraft 1.21.4 слот belowname отображает здоровье или очки скорборда сервера.
     * Мы полностью отменяем его отрисовку на стороне клиента.
     */
    @Inject(
        method = "renderLabelIfPresent(Lnet/minecraft/client/network/AbstractClientPlayerEntity;Lnet/minecraft/text/Text;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;IF)V",
        at = @At("HEAD"),
        cancellable = true
    )
    protected void onRenderLabelIfPresent(AbstractClientPlayerEntity entity, Text text, MatrixStack matrixStack, VertexConsumerProvider vertexConsumerProvider, int light, float tickDelta, CallbackInfo ci) {
        if (entity.getScoreboard() != null) {
            ScoreboardObjective objective = entity.getScoreboard().getObjectiveForSlot(ScoreboardDisplaySlot.BELOW_NAME);
            if (objective != null) {
                // Отменяем отрисовку метки belowname
                ci.cancel();
            }
        }
    }
}
